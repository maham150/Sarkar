const evidenceData=[
 {id:'note',emoji:'📝',name:'Folded note',desc:'A tiny note is tucked beneath the desk lamp.',evidence:'Evidence 01: The anniversary is 19 October.',hint:'The day matters more than the month.'},
 {id:'key',emoji:'🗝️',name:'Old key',desc:'A brass key is taped under the desk.',evidence:'Evidence 02: The archive needs a four-digit code.',hint:'Use the day of the anniversary and the last two digits of 1910.'},
 {id:'photo',emoji:'🖼️',name:'Polaroid',desc:'A photo frame is turned face down.',evidence:'Evidence 03: The best clues are shared memories.',hint:'Look for the thing that grows when shared.'},
 {id:'box',emoji:'📦',name:'Archive box',desc:'The box has a small heart scratched into its lid.',evidence:'Evidence 04: The final vault holds a friendship message.',hint:'The last step is to put the memory back in order.'},
 {id:'plant',emoji:'🪴',name:'Desk plant',desc:'The soil is damp. Nothing is hidden here, but someone watered it recently.',evidence:null,hint:'Not every object holds evidence. Keep looking.'},
 {id:'clock',emoji:'🕰️',name:'Stopped clock',desc:'The clock stopped at 2:00 AM—the time the memory went missing.',evidence:null,hint:'The time is part of the story, not the code.'}
];
let found=new Set(),memorySelected=new Set();
const $=id=>document.getElementById(id);
function showHow(){$('how').classList.toggle('hidden')}
function startGame(){$('intro').classList.add('hidden');$('room').classList.remove('hidden');renderObjects();updateProgress();window.scrollTo(0,0)}
function renderObjects(){$('objects').innerHTML='';evidenceData.forEach(o=>{let b=document.createElement('button');b.className='object'+(found.has(o.id)?' found':'');b.innerHTML=`<span class="emoji">${o.emoji}</span><strong>${o.name}</strong><small>${found.has(o.id)?'✓ Investigated':'Tap to inspect'}</small>`;b.onclick=()=>inspect(o);$('objects').appendChild(b)})}
function inspect(o){if(found.has(o.id)){$('roomMsg').textContent=o.desc+' '+(o.evidence||o.hint);return}if(o.evidence){found.add(o.id);$('roomMsg').textContent='Evidence collected! '+o.evidence;updateInventory();renderObjects();$('foundCount').textContent=`Evidence: ${found.size} / 4`;if(found.size===4)$('toLock').disabled=false}else{$('roomMsg').textContent=o.desc+' '+o.hint}updateProgress()}
function updateInventory(){$('inventory').innerHTML='';if(!found.size){$('inventory').innerHTML='<span>No evidence collected yet.</span>';return}evidenceData.filter(o=>found.has(o.id)).forEach(o=>{let s=document.createElement('span');s.textContent=o.evidence;$('inventory').appendChild(s)})}
function updateProgress(){$('progress').textContent=found.size===4?'CASE STATUS: EVIDENCE SECURED':`CASE STATUS: ${found.size}/4 EVIDENCE`}
function goLock(){if(found.size<4)return;$('room').classList.add('hidden');$('lock').classList.remove('hidden');window.scrollTo(0,0)}
function backRoom(){$('lock').classList.add('hidden');$('room').classList.remove('hidden')}
function checkCode(){if($('code').value.trim()==='1910'){$('codeMsg').textContent='Access granted. Archive unlocked. 🔓';setTimeout(()=>{$('lock').classList.add('hidden');$('riddle').classList.remove('hidden');window.scrollTo(0,0)},600)}else{$('codeMsg').textContent='Access denied. Re-read the evidence and try again.'}}
function answerRiddle(a){if(a==='friendship'){$('riddleMsg').textContent='Correct. Friendship is the evidence that connects every clue. 💗';setTimeout(()=>{$('riddle').classList.add('hidden');$('friendQuiz').classList.remove('hidden');renderQuiz();window.scrollTo(0,0)},700)}else{$('riddleMsg').textContent='Not quite, detective. Think of something that grows when it is shared.'}}
const friendshipQuiz=[
 {q:"It’s 2:00 AM and one of us texts: “Are you awake?” What happens next?",a:[["🌙","“I am now. Tell me everything.”",1],["👀","Send “WHAT HAPPENED???” in 0.2 seconds",0],["🫡","Call immediately. Texting is too slow for this mission.",2]]},
 {q:"We have one hour together and absolutely no plan. Best-case scenario?",a:[["🍟","Find snacks, then somehow start a three-hour conversation",0],["🚶","Go somewhere random and make it a core memory",2],["🛋️","Do nothing together—and still have the best time",1]]},
 {q:"A suspicious message says “I need to tell you something…” What’s your REAL first reaction?",a:[["😳","Replay every recent conversation in my head",1],["🕵️","Become a detective and ask 17 questions",2],["😭","Reply “BHAI SEEDHA BOLO, suspense kyun?”",0]]},
 {q:"Our friendship gets turned into a secret mission. What role do you take?",a:[["🧠","The planner who notices tiny details",2],["🎭","The chaos agent who improvises everything",0],["🫶","The one who keeps the team together when things go wrong",1]]},
 {q:"Years later, we find an old chat screenshot. What makes us laugh hardest?",a:[["🫠","The dramatic messages that felt life-or-death at the time",0],["🥹","A tiny moment that proves how much we’ve changed",1],["🤨","The completely random conversation that makes zero sense now",2]]}
];
let quizIndex=0,quizAnswers=Array(5).fill(null);
function renderQuiz(){
 const q=friendshipQuiz[quizIndex];$('quizQuestion').textContent=(quizIndex+1)+'. '+q.q;
 $('quizProgress').textContent=`Question ${quizIndex+1} of ${friendshipQuiz.length}`;
 $('quizOptions').innerHTML='';
 q.a.forEach((a,i)=>{const b=document.createElement('button');b.className='quiz-option'+(quizAnswers[quizIndex]===i?' selected':'');b.innerHTML=`<span class="opt-icon">${a[0]}</span><span>${a[1]}</span>`;b.onclick=()=>{quizAnswers[quizIndex]=i;renderQuiz()};$('quizOptions').appendChild(b)});
 $('quizBack').disabled=quizIndex===0;$('quizNext').disabled=quizAnswers[quizIndex]===null;
 $('quizNext').textContent=quizIndex===friendshipQuiz.length-1?'Reveal our friendship vibe ✨':'Next question →';
 $('quizMsg').textContent=quizAnswers[quizIndex]===null?'Choose the answer that feels most like your friendship.':'Answer saved! 💗';
}
function quizPrevious(){if(quizIndex>0){quizIndex--;renderQuiz()}}
function quizNext(){if(quizAnswers[quizIndex]===null){$('quizMsg').textContent='Choose an answer first, detective!';return}if(quizIndex<friendshipQuiz.length-1){quizIndex++;renderQuiz();return}
 let scores=[0,0,0];quizAnswers.forEach((answer,i)=>scores[friendshipQuiz[i].a[answer][2]]++);
 const max=Math.max(...scores);let result;
 if(scores[0]===max&&scores[1]!==max&&scores[2]!==max)result='THE CHAOS DUO 😂 — inside jokes, dramatic reactions, and “you had to be there” stories. Your friendship could turn a grocery run into a full episode.';
 else if(scores[1]===max&&scores[0]!==max&&scores[2]!==max)result='THE SAFE-PLACE FRIENDS 💗 — you can be silly, quiet, dramatic, or honest around each other. The magic is feeling understood without having to perform.';
 else if(scores[2]===max&&scores[0]!==max&&scores[1]!==max)result='THE TWO-PERSON DETECTIVE AGENCY 🕵️ — you notice details, investigate every plot twist, and never leave your partner-in-crime to solve a mystery alone.';
 else result='THE UNPREDICTABLE DUO ✨ — impossible to put in one category: equal parts chaos, comfort, and detective energy. That mix is exactly what makes your friendship yours.';
 $('friendQuiz').classList.add('hidden');$('cipher').classList.remove('hidden');$('cipherHint').textContent=result+' Next up: crack the encrypted file. Take your time—you can use hints.';window.scrollTo(0,0);
}
let cipherHintsUsed=0;
const cipherHintTexts=[
 "Use the key printed under the numbers: A=1, B=2, C=3 … Each number points to a letter in the alphabet.",
 "If a letter was moved forward one place to encrypt it, reverse the move. For example, D would become C.",
 "The anniversary day is 19. Count the letters in the word you decoded in Stage 2, then put that count after 19. Use two digits for the count."
];
function hintCipher(stage){cipherHintsUsed=Math.max(cipherHintsUsed,stage);$('cipherHint').textContent='Hint '+stage+': '+cipherHintTexts[stage-1];}
function checkCipher(){
 const a=$('cipher1').value.trim().toUpperCase(),b=$('cipher2').value.trim().toUpperCase(),c=$('cipher3').value.trim();
 let ok=true;
 if(a!=='LOVE'){$('cipher1Msg').textContent='Not quite. Re-check each number against the alphabet.';ok=false}else $('cipher1Msg').textContent='Stage 1 accepted. ✨';
 if(b!=='FRIEND'){$('cipher2Msg').textContent='Not yet. Reverse the shift for every letter.';ok=false}else $('cipher2Msg').textContent='Stage 2 accepted. 🔓';
 if(c!=='1906'){$('cipher3Msg').textContent='The final lock stays closed. Re-check the anniversary day and letter count.';ok=false}else $('cipher3Msg').textContent='Final lock accepted. 💗';
 if(ok){$('cipherHint').textContent='Archive unlocked! The clues were difficult, but you kept going. That is the real detective energy. 💗';setTimeout(()=>{$('cipher').classList.add('hidden');$('jigsaw').classList.remove('hidden');$('tileMsg').textContent='The encrypted file is open. Now decode the final memory board.';window.scrollTo(0,0)},800)}
}
function backToQuiz(){$('cipher').classList.add('hidden');$('friendQuiz').classList.remove('hidden');renderQuiz();window.scrollTo(0,0);}
function toggleMemory(button){const symbol=button.dataset.symbol;if(memorySelected.has(symbol)){memorySelected.delete(symbol);button.classList.remove('found')}else{if(memorySelected.size>=3){$('tileMsg').textContent='Choose only three symbols. Remove one first if you want to change your board.';return}memorySelected.add(symbol);button.classList.add('found')} $('memoryCount').textContent=`Selected: ${memorySelected.size} / 3`;$('tileMsg').textContent=''}
function clearMemory(){memorySelected.clear();document.querySelectorAll('#memoryChoices .object').forEach(b=>b.classList.remove('found'));$('memoryCount').textContent='Selected: 0 / 3';$('tileMsg').textContent='Your evidence board is cleared.'}
function checkMemory(){if(memorySelected.size!==3){$('tileMsg').textContent='Select exactly three symbols before submitting.';return}const correct=['photo','letter','heart'];if(correct.every(s=>memorySelected.has(s))){$('tileMsg').textContent='All three clues line up. The archive recognises your deduction. Memory restored. ✨';setTimeout(()=>{$('jigsaw').classList.add('hidden');$('ending').classList.remove('hidden');$('progress').textContent='CASE STATUS: CLOSED ✓';window.scrollTo(0,0)},700)}else{$('tileMsg').textContent='Two clues may fit, but one symbol is a decoy. Re-read the note: captures a moment, carries a message, connects two people.'}}
function restart(){found.clear();memorySelected.clear();['room','lock','riddle','friendQuiz','cipher','jigsaw','ending'].forEach(id=>$(id).classList.add('hidden'));$('intro').classList.remove('hidden');$('code').value='';$('codeMsg').textContent='';$('riddleMsg').textContent='';$('roomMsg').textContent='';quizIndex=0;quizAnswers=Array(5).fill(null);cipherHintsUsed=0;['cipher1','cipher2','cipher3'].forEach(id=>$(id).value='');['cipher1Msg','cipher2Msg','cipher3Msg'].forEach(id=>$(id).textContent='');$('cipherHint').textContent='Hints are available one at a time. Try to solve each stage before opening one.';$('tileMsg').textContent='';$('memoryCount').textContent='Selected: 0 / 3';document.querySelectorAll('#memoryChoices .object').forEach(b=>b.classList.remove('found'));$('foundCount').textContent='Evidence: 0 / 4';$('toLock').disabled=true;updateInventory();updateProgress();window.scrollTo(0,0)}
